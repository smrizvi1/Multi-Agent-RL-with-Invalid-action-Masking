# Paper-Aligned UAV-NOMA Implementation

This implementation follows the paper's approach of using invalid action masking integrated into the DQN architecture. It includes the following features:

## Features
- Integrated action masking in network architecture
- Post-prediction masking for Q-values
- Dynamic cluster-size based action space
- Multi-UAV trajectory optimization
- NOMA power allocation
- User clustering and association

## System Requirements
- Python 3.8+
- TensorFlow 2.x
- NumPy
- Pandas
- Matplotlib
- Scikit-learn

## Architecture
- Separate DQN and action masking implementations
- Action masking applied during Q-value prediction
- Flexible power allocation based on cluster size
- Invalid actions masked with -inf values

## Usage
```bash
python src/main.py
```

## Key Differences from Basic Implementation
- Action masking integrated into network architecture
- Enhanced state abstraction for better generalization
- More sophisticated power allocation schemes
- Improved user clustering mechanism