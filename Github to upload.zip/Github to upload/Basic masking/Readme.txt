# Basic UAV-NOMA Implementation

This repository contains a basic implementation of UAV-enabled NOMA (Non-Orthogonal Multiple Access) communications using Deep Q-Learning.

## Features
- Multi-UAV trajectory optimization
- NOMA power allocation
- Deep Q-Network for joint optimization
- User clustering and association

## System Requirements
- Python 3.8+
- TensorFlow 2.x
- NumPy
- Pandas
- Matplotlib
- Scikit-learn

## File Structure
- `src/main.py`: Main training loop and experiment setup
- `src/models/dqn.py`: DQN implementation
- `src/models/system_model.py`: UAV-NOMA system model
- `src/utils/helpers.py`: Helper functions for calculations

## Usage
```bash
python src/main.py
```

## Parameters
- Number of UAVs: 3
- Users per cell: 2
- Service zone: 500m x 500m
- UAV speed: 5 m/s
- Carrier frequency: 2 GHz
- Bandwidth: 30 kHz